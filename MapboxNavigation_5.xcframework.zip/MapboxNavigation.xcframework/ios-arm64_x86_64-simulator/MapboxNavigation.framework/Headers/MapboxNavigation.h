#import <UIKit/UIKit.h>

//! Project version number for MapboxNavigation.
FOUNDATION_EXPORT double MapboxNavigationVersionNumber;

//! Project version string for MapboxNavigation.
FOUNDATION_EXPORT const unsigned char MapboxNavigationVersionString[];

#import "MBRouteVoiceController.h"
#import "MGLMapView+MGLNavigationAdditions.h"
